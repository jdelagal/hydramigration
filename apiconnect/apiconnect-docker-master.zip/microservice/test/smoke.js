// Copyright IBM Corp. 2015. All Rights Reserved.
// Node module: loopback-example-database
// This file is licensed under the MIT License.
// License text available at https://opensource.org/licenses/MIT

var test = require('tape');

test('smoke test', function(t) {
  t.equal(1, 1);
  t.end();
});
